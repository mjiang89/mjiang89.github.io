% Copyright by Meng Jiang
 compute_eigenvector('graph_random_powerlaw','u_random_powerlaw','v_random_powerlaw');
 compute_eigenvector('graph_two_blocks','u_two_blocks','v_two_blocks');
 compute_eigenvector('graph_two_blocks_camou','u_two_blocks_camou','v_two_blocks_camou');
 compute_eigenvector('graph_staircase','u_staircase','v_staircase');