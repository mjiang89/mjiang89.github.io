A toy example to generate the injected graph and use Get-the-Scoop to detect the injected node groups.

1. python: Run graph_generator.py

2. Matlab: Run run_compute_eigenvector.m

3. R: Run plot_eigenvector.R

4. python: Run get_the_scoop.py