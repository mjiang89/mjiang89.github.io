
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


data = pd.read_csv('/Users/meng/Desktop/csranking.txt',sep='\t')
print data


# In[3]:


columnname = 'Faculty'

column = data[columnname]
print column.describe()


# In[4]:


n = column.count()
print 'n',n

x2freq = {}
for i in range(0,n):
	x = column.loc[i]
	if not x in x2freq: x2freq[x] = 0
	x2freq[x] += 1
x_freq = sorted(x2freq.items(),key=lambda x:-x[1])
print 'absolute frequency',x_freq[:2]
print 'mode',x_freq[0][0]


# In[5]:


_mean_ = 0.0
for i in range(0,n):
	_mean_ += column.loc[i]
_mean_ = _mean_/n
print 'mean',_mean_

_std_ = 0.0
for i in range(0,n):
	_std_ += (column.loc[i]-_mean_)*(column.loc[i]-_mean_)
_std_ = (_std_/(n-1))**0.5
print 'std',_std_

_std_ = 0.0
for i in range(0,n):
	_std_ += (column.loc[i]-_mean_)*(column.loc[i]-_mean_)
_std_ = (_std_/n)**0.5
print 'biased std',_std_


# In[6]:


_min_ = min(column)
_max_ = max(column)
data['MinMax'] = (column-_min_)/(_max_-_min_)
data['ZScore'] = (column-_mean_)/_std_
print data[['Institution','Faculty','MinMax','ZScore']]


# In[7]:


columnname = 'Count'

column = data[columnname]
print column.describe()


# In[9]:


n = column.count()
print 'n',n

x2freq = {}
for i in range(0,n):
	x = column.loc[i]
	if not x in x2freq: x2freq[x] = 0
	x2freq[x] += 1
x_freq = sorted(x2freq.items(),key=lambda x:-x[1])
print 'absolute frequency',x_freq[:2]
print 'mode',x_freq[0][0]


# In[10]:


_mean_ = 0.0
for i in range(0,n):
	_mean_ += column.loc[i]
_mean_ = _mean_/n
print 'mean',_mean_

_std_ = 0.0
for i in range(0,n):
	_std_ += (column.loc[i]-_mean_)*(column.loc[i]-_mean_)
_std_ = (_std_/(n-1))**0.5
print 'std',_std_

_std_ = 0.0
for i in range(0,n):
	_std_ += (column.loc[i]-_mean_)*(column.loc[i]-_mean_)
_std_ = (_std_/n)**0.5
print 'biased std',_std_


# In[11]:


_min_ = min(column)
_max_ = max(column)
data['MinMax'] = (column-_min_)/(_max_-_min_)
data['ZScore'] = (column-_mean_)/_std_
print data[['Institution','Faculty','MinMax','ZScore']]

