from sklearn import svm
import random

def shorten(x):
	return 0.001*int(1000.0*x)

conf_features = []
feature2count = {}
fr = open('paper2attributes2label.txt','rb')
for line in fr:
	arr = line.strip('\r\n').split('\t')
	conf = arr[1]
	features = arr[2].split(',')
	conf_features.append([conf,features])
	for feature in features:
		if not feature in feature2count:
			feature2count[feature] = 0
		feature2count[feature] += 1
fr.close()
feature_count = sorted(feature2count.items(),key=lambda x:-x[1])
nfeatureall = len(feature_count)
print 'number of features (all):',nfeatureall

print '----- Test on Training: Convergence? -----'

# test on training: Convergence?
for nfeature in range(10,201,10):
	feature2fid = {}
	for fid in range(nfeature):
		feature = feature_count[fid][0]
		feature2fid[feature] = fid
	X = [] # features
	y = [] # label
	for [conf,features] in conf_features:
		instance = [0 for i in range(nfeature)]
		isvalid = False
		for feature in features:
			if not feature in feature2fid: continue
			fid = feature2fid[feature]
			instance[fid] = 1
			isvalid = True
		if not isvalid: continue
		X.append(instance)
		if conf == 'kdd':
			y.append(1)
		else:
			y.append(0)
	ninstance = len(X)

	model = svm.SVC()
	model.fit(X,y)
	_y = model.predict(X)
	TP,FP,TN,FN = 0,0,0,0
	for i in range(ninstance):
		if y[i] == 1 and _y[i] == 1: TP += 1
		if y[i] == 0 and _y[i] == 0: TN += 1
		if y[i] == 0 and _y[i] == 1: FP += 1
		if y[i] == 1 and _y[i] == 0: FN += 1
	accuracy = 1.0*(TP+TN)/ninstance
	precision = 1.0*TP/(TP+FP)
	recall = 1.0*TP/(TP+FN)
	f1 = 2.0*precision*recall/(precision+recall)

	print '#f',nfeature,'#i',ninstance,'|', \
		'A',shorten(accuracy),'P',shorten(precision),'R',shorten(recall),'F1',shorten(f1)

print '----- Allowing for Errors: the value of C -----'

# allowing for errors: the value of C?
for nfeature in range(10,201,10):
	feature2fid = {}
	for fid in range(nfeature):
		feature = feature_count[fid][0]
		feature2fid[feature] = fid
	X = [] # features
	y = [] # label
	for [conf,features] in conf_features:
		instance = [0 for i in range(nfeature)]
		isvalid = False
		for feature in features:
			if not feature in feature2fid: continue
			fid = feature2fid[feature]
			instance[fid] = 1
			isvalid = True
		if not isvalid: continue
		X.append(instance)
		if conf == 'kdd':
			y.append(1)
		else:
			y.append(0)
	ninstance = len(X)

	model = svm.SVC(C=5.0)
	model.fit(X,y)
	_y = model.predict(X)
	TP,FP,TN,FN = 0,0,0,0
	for i in range(ninstance):
		if y[i] == 1 and _y[i] == 1: TP += 1
		if y[i] == 0 and _y[i] == 0: TN += 1
		if y[i] == 0 and _y[i] == 1: FP += 1
		if y[i] == 1 and _y[i] == 0: FN += 1
	accuracy = 1.0*(TP+TN)/ninstance
	precision = 1.0*TP/(TP+FP)
	recall = 1.0*TP/(TP+FN)
	f1 = 2.0*precision*recall/(precision+recall)

	print '#f',nfeature,'#i',ninstance,'|', \
		'A',shorten(accuracy),'P',shorten(precision),'R',shorten(recall),'F1',shorten(f1)

print '----- Holdout Validation: Over-fitting? -----'

# holdout validation: Over-fitting?
K = 3
training_ratio = 0.8
for nfeature in range(5,101,5):
	feature2fid = {}
	for fid in range(nfeature):
		feature = feature_count[fid][0]
		feature2fid[feature] = fid
	X = [] # features
	y = [] # label
	for [conf,features] in conf_features:
		instance = [0 for i in range(nfeature)]
		isvalid = False
		for feature in features:
			if not feature in feature2fid: continue
			fid = feature2fid[feature]
			instance[fid] = 1
			isvalid = True
		if not isvalid: continue
		X.append(instance)
		if conf == 'kdd':
			y.append(1)
		else:
			y.append(0)
	ninstance = len(X)
	X_y = [[X[i],y[i]] for i in range(ninstance)]
	ntrain = int(training_ratio*ninstance)
	ntest = ninstance-ntrain

	list_accuracy,list_precision,list_recall,list_f1 = [],[],[],[]
	list_accuracy_test,list_precision_test,list_recall_test,list_f1_test = [],[],[],[]
	for k in range(K):
		random.shuffle(X_y)
		X_train = [X_y[i][0] for i in range(ntrain)]
		y_train = [X_y[i][1] for i in range(ntrain)]
		X_test = [X_y[i][0] for i in range(ntrain,ninstance)]
		y_test = [X_y[i][1] for i in range(ntrain,ninstance)]

		model = svm.SVC()
		model.fit(X_train,y_train)

		_y = model.predict(X_train)
		TP,FP,TN,FN = 0,0,0,0
		for i in range(ntrain):
			if y_train[i] == 1 and _y[i] == 1: TP += 1
			if y_train[i] == 0 and _y[i] == 0: TN += 1
			if y_train[i] == 0 and _y[i] == 1: FP += 1
			if y_train[i] == 1 and _y[i] == 0: FN += 1
		accuracy = 1.0*(TP+TN)/ntrain
		precision = 1.0*TP/(TP+FP)
		recall = 1.0*TP/(TP+FN)
		f1 = 2.0*precision*recall/(precision+recall)
		list_accuracy.append(accuracy)
		list_precision.append(precision)
		list_recall.append(recall)
		list_f1.append(f1)

		_y = model.predict(X_test)
		TP,FP,TN,FN = 0,0,0,0
		for i in range(ntest):
			if y_test[i] == 1 and _y[i] == 1: TP += 1
			if y_test[i] == 0 and _y[i] == 0: TN += 1
			if y_test[i] == 0 and _y[i] == 1: FP += 1
			if y_test[i] == 1 and _y[i] == 0: FN += 1
		accuracy = 1.0*(TP+TN)/ntest
		precision = 1.0*TP/(TP+FP)
		recall = 1.0*TP/(TP+FN)
		f1 = 2.0*precision*recall/(precision+recall)
		list_accuracy_test.append(accuracy)
		list_precision_test.append(precision)
		list_recall_test.append(recall)
		list_f1_test.append(f1)

	accuracy = sum(list_accuracy)/K
	precision = sum(list_precision)/K
	recall = sum(list_recall)/K
	f1 = sum(list_f1)/K
	std_accuracy = (sum([(x-accuracy)**2.0 for x in list_accuracy])/K)**0.5
	std_precision = (sum([(x-precision)**2.0 for x in list_precision])/K)**0.5
	std_recall = (sum([(x-recall)**2.0 for x in list_recall])/K)**0.5
	std_f1 = (sum([(x-f1)**2.0 for x in list_f1])/K)**0.5

	accuracy_test = sum(list_accuracy_test)/K
	precision_test = sum(list_precision_test)/K
	recall_test = sum(list_recall_test)/K
	f1_test = sum(list_f1_test)/K
	std_accuracy_test = (sum([(x-accuracy_test)**2.0 for x in list_accuracy_test])/K)**0.5
	std_precision_test = (sum([(x-precision_test)**2.0 for x in list_precision_test])/K)**0.5
	std_recall_test = (sum([(x-recall_test)**2.0 for x in list_recall_test])/K)**0.5
	std_f1_test = (sum([(x-f1_test)**2.0 for x in list_f1_test])/K)**0.5

	print '#f',nfeature,'#i',ntrain,ntest,'|', \
		'A',shorten(accuracy),shorten(std_accuracy), \
		'P',shorten(precision),shorten(std_precision), \
		'R',shorten(recall),shorten(std_recall), \
		'F1',shorten(f1),shorten(std_f1),'|', \
		'At',shorten(accuracy_test),shorten(std_accuracy_test), \
		'Pt',shorten(precision_test),shorten(std_precision_test), \
		'Rt',shorten(recall_test),shorten(std_recall_test), \
		'F1t',shorten(f1_test),shorten(std_f1_test)

print '----- Holdout Validation: Over-fitting? (When C = 5.0) -----'

# holdout validation: Over-fitting? (When C = 5.0)
K = 3
training_ratio = 0.8
for nfeature in range(5,101,5):
	feature2fid = {}
	for fid in range(nfeature):
		feature = feature_count[fid][0]
		feature2fid[feature] = fid
	X = [] # features
	y = [] # label
	for [conf,features] in conf_features:
		instance = [0 for i in range(nfeature)]
		isvalid = False
		for feature in features:
			if not feature in feature2fid: continue
			fid = feature2fid[feature]
			instance[fid] = 1
			isvalid = True
		if not isvalid: continue
		X.append(instance)
		if conf == 'kdd':
			y.append(1)
		else:
			y.append(0)
	ninstance = len(X)
	X_y = [[X[i],y[i]] for i in range(ninstance)]
	ntrain = int(training_ratio*ninstance)
	ntest = ninstance-ntrain

	list_accuracy,list_precision,list_recall,list_f1 = [],[],[],[]
	list_accuracy_test,list_precision_test,list_recall_test,list_f1_test = [],[],[],[]
	for k in range(K):
		random.shuffle(X_y)
		X_train = [X_y[i][0] for i in range(ntrain)]
		y_train = [X_y[i][1] for i in range(ntrain)]
		X_test = [X_y[i][0] for i in range(ntrain,ninstance)]
		y_test = [X_y[i][1] for i in range(ntrain,ninstance)]

		model = svm.SVC(C=5.0)
		model.fit(X_train,y_train)

		_y = model.predict(X_train)
		TP,FP,TN,FN = 0,0,0,0
		for i in range(ntrain):
			if y_train[i] == 1 and _y[i] == 1: TP += 1
			if y_train[i] == 0 and _y[i] == 0: TN += 1
			if y_train[i] == 0 and _y[i] == 1: FP += 1
			if y_train[i] == 1 and _y[i] == 0: FN += 1
		accuracy = 1.0*(TP+TN)/ntrain
		precision = 1.0*TP/(TP+FP)
		recall = 1.0*TP/(TP+FN)
		f1 = 2.0*precision*recall/(precision+recall)
		list_accuracy.append(accuracy)
		list_precision.append(precision)
		list_recall.append(recall)
		list_f1.append(f1)

		_y = model.predict(X_test)
		TP,FP,TN,FN = 0,0,0,0
		for i in range(ntest):
			if y_test[i] == 1 and _y[i] == 1: TP += 1
			if y_test[i] == 0 and _y[i] == 0: TN += 1
			if y_test[i] == 0 and _y[i] == 1: FP += 1
			if y_test[i] == 1 and _y[i] == 0: FN += 1
		accuracy = 1.0*(TP+TN)/ntest
		precision = 1.0*TP/(TP+FP)
		recall = 1.0*TP/(TP+FN)
		f1 = 2.0*precision*recall/(precision+recall)
		list_accuracy_test.append(accuracy)
		list_precision_test.append(precision)
		list_recall_test.append(recall)
		list_f1_test.append(f1)

	accuracy = sum(list_accuracy)/K
	precision = sum(list_precision)/K
	recall = sum(list_recall)/K
	f1 = sum(list_f1)/K
	std_accuracy = (sum([(x-accuracy)**2.0 for x in list_accuracy])/K)**0.5
	std_precision = (sum([(x-precision)**2.0 for x in list_precision])/K)**0.5
	std_recall = (sum([(x-recall)**2.0 for x in list_recall])/K)**0.5
	std_f1 = (sum([(x-f1)**2.0 for x in list_f1])/K)**0.5

	accuracy_test = sum(list_accuracy_test)/K
	precision_test = sum(list_precision_test)/K
	recall_test = sum(list_recall_test)/K
	f1_test = sum(list_f1_test)/K
	std_accuracy_test = (sum([(x-accuracy_test)**2.0 for x in list_accuracy_test])/K)**0.5
	std_precision_test = (sum([(x-precision_test)**2.0 for x in list_precision_test])/K)**0.5
	std_recall_test = (sum([(x-recall_test)**2.0 for x in list_recall_test])/K)**0.5
	std_f1_test = (sum([(x-f1_test)**2.0 for x in list_f1_test])/K)**0.5

	print '#f',nfeature,'#i',ntrain,ntest,'|', \
		'A',shorten(accuracy),shorten(std_accuracy), \
		'P',shorten(precision),shorten(std_precision), \
		'R',shorten(recall),shorten(std_recall), \
		'F1',shorten(f1),shorten(std_f1),'|', \
		'At',shorten(accuracy_test),shorten(std_accuracy_test), \
		'Pt',shorten(precision_test),shorten(std_precision_test), \
		'Rt',shorten(recall_test),shorten(std_recall_test), \
		'F1t',shorten(f1_test),shorten(std_f1_test)

print '----- Multi-class Support Vector Clasification -----'

# multiclass SVC
K = 3
training_ratio = 0.8
conf2label = {}
for nfeature in range(5,101,5):
	feature2fid = {}
	for fid in range(nfeature):
		feature = feature_count[fid][0]
		feature2fid[feature] = fid
	X = [] # features
	y = [] # label
	for [conf,features] in conf_features:
		instance = [0 for i in range(nfeature)]
		isvalid = False
		for feature in features:
			if not feature in feature2fid: continue
			fid = feature2fid[feature]
			instance[fid] = 1
			isvalid = True
		if not isvalid: continue
		X.append(instance)
		if not conf in conf2label:
			conf2label[conf] = len(conf2label)
		label = conf2label[conf]
		y.append(label)
	ninstance = len(X)
	X_y = [[X[i],y[i]] for i in range(ninstance)]
	ntrain = int(training_ratio*ninstance)
	ntest = ninstance-ntrain

	list_accuracy = []
	list_accuracy_test = []
	for k in range(K):
		random.shuffle(X_y)
		X_train = [X_y[i][0] for i in range(ntrain)]
		y_train = [X_y[i][1] for i in range(ntrain)]
		X_test = [X_y[i][0] for i in range(ntrain,ninstance)]
		y_test = [X_y[i][1] for i in range(ntrain,ninstance)]

		model = svm.SVC()
		model.fit(X_train,y_train)

		_y = model.predict(X_train)
		hit = 0
		for i in range(ntrain):
			if y_train[i] == _y[i]: hit += 1
		accuracy = 1.0*hit/ntrain
		list_accuracy.append(accuracy)

		_y = model.predict(X_test)
		hit = 0
		for i in range(ntest):
			if y_test[i] == _y[i] == 1: hit += 1
		accuracy = 1.0*hit/ntest
		list_accuracy_test.append(accuracy)

	accuracy = sum(list_accuracy)/K
	std_accuracy = (sum([(x-accuracy)**2.0 for x in list_accuracy])/K)**0.5

	accuracy_test = sum(list_accuracy_test)/K
	std_accuracy_test = (sum([(x-accuracy_test)**2.0 for x in list_accuracy_test])/K)**0.5

	print '#f',nfeature,'#i',ntrain,ntest,'|', \
		'A',shorten(accuracy),shorten(std_accuracy),'|', \
		'At',shorten(accuracy_test),shorten(std_accuracy_test)

print '----- Multi-class Support Vector Clasification (When C = 5.0) -----'

# multiclass SVC (When C = 5.0)
K = 3
training_ratio = 0.8
conf2label = {}
for nfeature in range(5,101,5):
	feature2fid = {}
	for fid in range(nfeature):
		feature = feature_count[fid][0]
		feature2fid[feature] = fid
	X = [] # features
	y = [] # label
	for [conf,features] in conf_features:
		instance = [0 for i in range(nfeature)]
		isvalid = False
		for feature in features:
			if not feature in feature2fid: continue
			fid = feature2fid[feature]
			instance[fid] = 1
			isvalid = True
		if not isvalid: continue
		X.append(instance)
		if not conf in conf2label:
			conf2label[conf] = len(conf2label)
		label = conf2label[conf]
		y.append(label)
	ninstance = len(X)
	X_y = [[X[i],y[i]] for i in range(ninstance)]
	ntrain = int(training_ratio*ninstance)
	ntest = ninstance-ntrain

	list_accuracy = []
	list_accuracy_test = []
	for k in range(K):
		random.shuffle(X_y)
		X_train = [X_y[i][0] for i in range(ntrain)]
		y_train = [X_y[i][1] for i in range(ntrain)]
		X_test = [X_y[i][0] for i in range(ntrain,ninstance)]
		y_test = [X_y[i][1] for i in range(ntrain,ninstance)]

		model = svm.SVC(C=5.0)
		model.fit(X_train,y_train)

		_y = model.predict(X_train)
		hit = 0
		for i in range(ntrain):
			if y_train[i] == _y[i]: hit += 1
		accuracy = 1.0*hit/ntrain
		list_accuracy.append(accuracy)

		_y = model.predict(X_test)
		hit = 0
		for i in range(ntest):
			if y_test[i] == _y[i] == 1: hit += 1
		accuracy = 1.0*hit/ntest
		list_accuracy_test.append(accuracy)

	accuracy = sum(list_accuracy)/K
	std_accuracy = (sum([(x-accuracy)**2.0 for x in list_accuracy])/K)**0.5

	accuracy_test = sum(list_accuracy_test)/K
	std_accuracy_test = (sum([(x-accuracy_test)**2.0 for x in list_accuracy_test])/K)**0.5

	print '#f',nfeature,'#i',ntrain,ntest,'|', \
		'A',shorten(accuracy),shorten(std_accuracy),'|', \
		'At',shorten(accuracy_test),shorten(std_accuracy_test)

