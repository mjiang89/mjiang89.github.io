import numpy as np
import pylab
import matplotlib.pyplot as plt
from scipy import stats as stat

math = [82,98,83,95,76,71,81,85,76]
ds = [84,97,83,97,87,73,83,87,83]

math.sort()
ds.sort()

##### Q-Q Plot #####
#Calculate quantiles
quantile_1 = np.arange(len(math),dtype=float)/len(math)
quantile_2 = np.arange(len(ds),dtype=float)/len(ds)

quantile = quantile_2
quantiles2 = ds

#using linear interpolation
quantiles1 = np.interp(quantile,quantile_1,math)
print quantiles1

#Plot the quantiles to create the qq plot
pylab.plot(quantiles1,quantiles2, marker='o', linestyle='-', color='b')

#Add a reference line
maxval = max(math[-1],ds[-1])
minval = min(math[0],ds[0])
pylab.plot([minval,maxval],[minval,maxval], linestyle='--')

plt.xlabel("Math", size=24)
plt.ylabel("Data Science", size=24)

pylab.show()

#### scatter plot ###
math = [82,98,83,95,76,71,81,85,76]
ds = [84,97,83,97,87,73,83,87,83]

fig = plt.figure()
ax = fig.gca()

plt.scatter(math, ds)

### grid of x-y axix ###
ax.set_xticks(np.arange(70, 101, 5))
ax.set_yticks(np.arange(70, 101, 5))

plt.xlabel("Math", size=24)
plt.ylabel("Data Science", size=24)

## fit a regression line ##
z = np.polyfit(math, ds, 1)
p = np.poly1d(z)
pylab.plot(math,p(math), linestyle=':', color='r')

plt.grid()
plt.show()

