##### HW1 Q3 SVD ######
import numpy as np
from scipy.sparse.linalg import svds, eigs
from scipy.sparse import csc_matrix

A=csc_matrix([[1,1,1,1,0,0,1,1,0], [1,1,1,1,0,0,1,1,0], [1,1,1,1,0,0,1,1,0],[1,1,1,1,0,0,1,1,0], [0,0,0,0,1,1,0,0,1], [0,0,0,0,1,1,0,0,1],[1,1,1,1,0,0,1,1,0], [1,1,1,1,0,0,1,1,0], [0,0,0,0,1,1,0,0,1]],dtype=float)

U, s, Vt = svds(A, k=2)

### Print U, the left singular vector ###
print(U)

### Print s, the singular values ###
print(s)
