import DecisionTree

def GamePredict(training_datafile,testing_datafile):
	dt = DecisionTree.DecisionTree(
		training_datafile = training_datafile,
		csv_class_column_index = 6,
		csv_columns_for_features = [3,4,5],
	)
	dt.get_training_data()
	dt.calculate_first_order_probabilities()
	dt.calculate_class_priors()
	dt.show_training_data()
	root_node = dt.construct_decision_tree_classifier()
	root_node.display_decision_tree(" ")
	fr = open(testing_datafile,'rb')
	fr.readline()
	for line in fr:
		arr = line.strip('\r\n').split(',')
		test_sample = []
		test_sample.append('HomeAway = '+arr[3])
		test_sample.append('Top25 = '+arr[4])
		test_sample.append('Media = '+arr[5])
		classification = dt.classify(root_node, test_sample)
		print "Test Sample:",test_sample
		print "Classification:",classification
	fr.close()

GamePredict("data.csv","test.csv")

