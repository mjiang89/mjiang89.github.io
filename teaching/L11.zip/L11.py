
# coding: utf-8

# In[1]:


from sklearn import svm
import math
import random
import numpy as np
import matplotlib.pyplot as plt


# In[2]:


def RunSVM(kernel_type,C_value,feature_train,label_train,feature_test,label_test):
    print(kernel_type+', C = '+str(C_value))
    model = svm.SVC(kernel = kernel_type, C = C_value)
    model.fit(feature_train,label_train)
    label_test_predicted = model.predict(feature_test)

    TP,FP,TN,FN = 0,0,0,0
    for i in range(n_test):
            if label_test[i] == 1 and label_test_predicted[i] == 1: TP += 1
            if label_test[i] == 0 and label_test_predicted[i] == 0: TN += 1
            if label_test[i] == 0 and label_test_predicted[i] == 1: FP += 1
            if label_test[i] == 1 and label_test_predicted[i] == 0: FN += 1
    accuracy = 1.0*(TP+TN)/n_test
    precision = 1.0*TP/(TP+FP)
    recall = 1.0*TP/(TP+FN)
    f1 = 2.0*precision*recall/(precision+recall)
    print('--------------')
    print('| TP',TP,'FN',FN,'|')
    print('| FP',FP,'TN',TN,'|')
    print('--------------')
    print('Accuracy =',accuracy)
    print('Precision = ',precision)
    print('Recall = ',recall)
    print('F1 = ',f1)
    print('--------------')


# In[3]:


b = 4.0
scale = 5.0
npoint_per_class = 200

data = []
for i in range(npoint_per_class):
    _math = b+random.random()*scale
    _stat = b+random.random()*scale
    data.append([_math,_stat,1]) # label = good
for i in range(npoint_per_class):
    _math = random.random()*scale
    _stat = random.random()*scale
    data.append([_math,_stat,0]) # label = bad

feature_train,label_train = [],[]
feature_test,label_test = [],[]
n = len(data)
n_train = int(0.6*n)
n_test = n-n_train
_ids = list(range(n))
random.shuffle(_ids)
for _id in _ids[0:n_train]:
    instance = data[_id]
    feature_train.append(instance[0:2])
    label_train.append(instance[2])
for _id in _ids[n_train:n]:
    instance = data[_id]
    feature_test.append(instance[0:2])
    label_test.append(instance[2])


# In[4]:


plt.figure(1)
for i in range(n_train):
    if label_train[i] == 1:
        plt.plot(feature_train[i][0],feature_train[i][1],'go')
    if label_train[i] == 0:
        plt.plot(feature_train[i][0],feature_train[i][1],'ro')
plt.title('train data')
plt.show()


# In[5]:


plt.figure(2)
for i in range(n_test):
    if label_test[i] == 1:
        plt.plot(feature_test[i][0],feature_test[i][1],'go')
    if label_test[i] == 0:
        plt.plot(feature_test[i][0],feature_test[i][1],'ro')
plt.title('test data')        
plt.show()


# In[6]:


RunSVM('linear',1.0,feature_train,label_train,feature_test,label_test)
RunSVM('rbf',1.0,feature_train,label_train,feature_test,label_test)


# In[7]:


RunSVM('linear',0.1,feature_train,label_train,feature_test,label_test)
RunSVM('rbf',0.1,feature_train,label_train,feature_test,label_test)


# In[8]:


RunSVM('linear',10.0,feature_train,label_train,feature_test,label_test)
RunSVM('rbf',10.0,feature_train,label_train,feature_test,label_test)


# In[15]:


b = 3.0
scale = 5.0
npoint_per_class = 200

data = []
for i in range(npoint_per_class):
    _math = b+random.random()*scale
    _stat = b+random.random()*scale
    data.append([_math,_stat,1]) # label = good
for i in range(npoint_per_class):
    _math = random.random()*scale
    _stat = random.random()*scale
    data.append([_math,_stat,0]) # label = bad

feature_train,label_train = [],[]
feature_test,label_test = [],[]
n = len(data)
n_train = int(0.6*n)
n_test = n-n_train
_ids = list(range(n))
random.shuffle(_ids)
for _id in _ids[0:n_train]:
    instance = data[_id]
    feature_train.append(instance[0:2])
    label_train.append(instance[2])
for _id in _ids[n_train:n]:
    instance = data[_id]
    feature_test.append(instance[0:2])
    label_test.append(instance[2])


# In[16]:


plt.figure(1)
for i in range(n_train):
    if label_train[i] == 1:
        plt.plot(feature_train[i][0],feature_train[i][1],'go')
    if label_train[i] == 0:
        plt.plot(feature_train[i][0],feature_train[i][1],'ro')
plt.title('train data')        
plt.show()


# In[17]:


plt.figure(2)
for i in range(n_test):
    if label_test[i] == 1:
        plt.plot(feature_test[i][0],feature_test[i][1],'go')
    if label_test[i] == 0:
        plt.plot(feature_test[i][0],feature_test[i][1],'ro')
plt.title('test data')        
plt.show()


# In[18]:


RunSVM('linear',1.0,feature_train,label_train,feature_test,label_test)
RunSVM('rbf',1.0,feature_train,label_train,feature_test,label_test)


# In[19]:


RunSVM('linear',0.1,feature_train,label_train,feature_test,label_test)
RunSVM('rbf',0.1,feature_train,label_train,feature_test,label_test)


# In[20]:


RunSVM('linear',10.0,feature_train,label_train,feature_test,label_test)
RunSVM('rbf',10.0,feature_train,label_train,feature_test,label_test)


# In[21]:


r_good = 4
r_bad = 2
npoint_per_class = 200

data = []
for i in range(npoint_per_class):
    _math = r_good+(random.random()*2-1)*r_good
    r = r_good*(random.random()*0.1+1.0)
    _stat = r_good+(math.sqrt(r*r-(_math-r_good)*(_math-r_good)))*(random.randint(0,1)*2-1)
    data.append([_math,_stat,1]) # label = good
for i in range(npoint_per_class):
    _math = r_good+(random.random()*2-1)*r_bad
    r = r_bad*(random.random()*0.1+1.0)
    _stat = r_good+(math.sqrt(r*r-(_math-r_good)*(_math-r_good)))*(random.randint(0,1)*2-1)
    data.append([_math,_stat,0]) # label = bad

feature_train,label_train = [],[]
feature_test,label_test = [],[]
n = len(data)
n_train = int(0.6*n)
n_test = n-n_train
_ids = list(range(n))
random.shuffle(_ids)
for _id in _ids[0:n_train]:
    instance = data[_id]
    feature_train.append(instance[0:2])
    label_train.append(instance[2])
for _id in _ids[0:n_train]:
    instance = data[_id]
    feature_test.append(instance[0:2])
    label_test.append(instance[2])


# In[22]:


plt.figure(1)
for i in range(n_train):
    if label_train[i] == 1:
        plt.plot(feature_train[i][0],feature_train[i][1],'go')
    if label_train[i] == 0:
        plt.plot(feature_train[i][0],feature_train[i][1],'ro')
plt.title('train data')        
plt.show()


# In[23]:


plt.figure(2)
for i in range(n_test):
    if label_test[i] == 1:
        plt.plot(feature_test[i][0],feature_test[i][1],'go')
    if label_test[i] == 0:
        plt.plot(feature_test[i][0],feature_test[i][1],'ro')
plt.title('test data')        
plt.show()


# In[24]:


RunSVM('linear',1.0,feature_train,label_train,feature_test,label_test)
RunSVM('rbf',1.0,feature_train,label_train,feature_test,label_test)


# In[25]:


RunSVM('linear',0.1,feature_train,label_train,feature_test,label_test)
RunSVM('rbf',0.1,feature_train,label_train,feature_test,label_test)


# In[26]:


RunSVM('linear',10.0,feature_train,label_train,feature_test,label_test)
RunSVM('rbf',10.0,feature_train,label_train,feature_test,label_test)

