
# coding: utf-8

# In[1]:


name_entity0 = []
fr = open('/Users/meng/Desktop/csranking.txt','rb')
fr.readline()
for line in fr:
	arr = line.strip('\r\n').split('\t')
	name = arr[1]
	entity = name[4:-4]
	entity = entity.replace('Univ.','University')
	name_entity0.append([name,entity,float(arr[2]),int(arr[3])]) # ranking_score, faculty
fr.close()
print '--> Number of Institutions (csranking):',len(name_entity0)


# In[2]:


name_entity1 = []
fr = open('/Users/meng/Desktop/cssalary.txt','rb')
fr.readline()
fr.readline()
for line in fr:
	arr = line.strip('\r\n').split('\t')
	name = arr[2]
	entity = name
	if ' - Main Campus' in entity:
		entity = entity[:-14]
	if ' (' in entity:
		pos0 = entity.find(' (')
		pos1 = entity.find(')')
		entity = entity[0:pos0]+entity[pos1+1:]
	name_entity1.append([name,entity,int(arr[3][1:].replace(',',''))]) # salary
fr.close()
print '--> Number of Institutions (cssalary):',len(name_entity1)


# In[3]:


entity2count = {}
for [name,entity,ranking_score,faculty] in name_entity0:
	if not entity in entity2count:
		entity2count[entity] = 0
	entity2count[entity] += 1
for [name,entity,salary] in name_entity1:
	if not entity in entity2count:
		entity2count[entity] = 0
	entity2count[entity] += 1
entityset = set()
for [entity,count] in sorted(entity2count.items(),key=lambda x:x[0]):
	if count == 2: entityset.add(entity)
	print entity	
print '--> Number of Institutions (integrated):',len(entityset)


# In[4]:


entity2features = {} # ranking_score, faculty, salary
for [name,entity,ranking_score,faculty] in name_entity0:
	if not entity in entityset: continue
	if not entity in entity2features:
		entity2features[entity] = [-1,-1,-1]
	entity2features[entity][0] = ranking_score
	entity2features[entity][1] = faculty
for [name,entity,salary] in name_entity1:
	if not entity in entityset: continue
	if not entity in entity2features:
		entity2features[entity] = [-1,-1,-1]
	entity2features[entity][2] = salary

_data_ = []
for [entity,[ranking_score,faculty,salary]] in sorted(entity2features.items(),key=lambda x:-x[1][0]):
	_data_.append([entity,ranking_score,faculty,salary])
	print entity,ranking_score,faculty,salary


# In[5]:


import pandas as pd
import numpy as np


# In[6]:


pairs = []
for [entity,ranking_score,faculty,salary] in _data_:
	pairs.append((ranking_score,faculty))
data = (pd.DataFrame(pairs))
print '--> ranking_score vs faculty:'
print np.cov(data,rowvar=False)[0][1]
print np.corrcoef(data,rowvar=False)[0][1]

pairs = []
for [entity,ranking_score,faculty,salary] in _data_:
	pairs.append((ranking_score,salary))
data = (pd.DataFrame(pairs))
print '--> ranking_score vs salary:'
print np.cov(data,rowvar=False)[0][1]
print np.corrcoef(data,rowvar=False)[0][1]

pairs = []
for [entity,ranking_score,faculty,salary] in _data_:
	pairs.append((faculty,salary))
data = (pd.DataFrame(pairs))
print '--> faculty vs salary:'
print np.cov(data,rowvar=False)[0][1]
print np.corrcoef(data,rowvar=False)[0][1]


# In[7]:


import matplotlib.pyplot as plt

list_ranking_score = []
list_faculty = []
list_salary = []
for [entity,ranking_score,faculty,salary] in _data_:
	list_ranking_score.append(ranking_score)
	list_faculty.append(faculty)
	list_salary.append(salary)
plt.figure()
plt.subplot(311)
pdscatter = plt.scatter(list_ranking_score,list_faculty)
plt.subplot(312)
pdscatter = plt.scatter(list_ranking_score,list_salary)
plt.subplot(313)
pdscatter = plt.scatter(list_faculty,list_salary)
plt.show()

