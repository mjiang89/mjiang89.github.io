
# coding: utf-8

# In[1]:


import numpy as np
from scipy import sparse
from scipy.sparse import linalg
import matplotlib.pyplot as plt


# In[2]:


x = 3
a = 1000
bs = [50,100,200]
n = a+sum(bs)
ea = 10*a
d = 0.9
ebs = [int(d*b*b) for b in bs]
e = ea+sum(ebs)
print n,ebs,e


# In[3]:


I = np.random.randint(a,size=ea)
J = np.random.randint(a,size=ea)
V = np.ones(ea)
A = sparse.coo_matrix((V,(I,J)),shape=(a,a))
U0,S,Vt = linalg.svds(A,k=3)

I = np.random.randint(a,size=ea)
J = np.random.randint(a,size=ea)
shift = a
for i in range(x):
	b = bs[i]
	eb = ebs[i]
	I = np.append(I,shift+np.random.randint(b,size=eb))
	J = np.append(J,shift+np.random.randint(b,size=eb))
	shift += b
V = np.ones(e)
A = sparse.coo_matrix((V,(I,J)),shape=(n,n))
U,S,Vt = linalg.svds(A,k=3)

plt.figure(4)
plt.subplot(221)
pdscatter = plt.scatter(U0[:,0],U0[:,1])
plt.subplot(222)
pdscatter = plt.scatter(U[:,0],U[:,1])
plt.subplot(223)
pdscatter = plt.scatter(U[:,0],U[:,2])
plt.subplot(224)
pdscatter = plt.scatter(U[:,1],U[:,2])
plt.show()


# In[4]:


x = 3
a = 1000
bs = [50,100,200]
n = a+sum(bs)
ea = 10*a
d = 0.5
ebs = [int(d*b*b) for b in bs]
e = ea+sum(ebs)
print n,ebs,e


# In[5]:


I = np.random.randint(a,size=ea)
J = np.random.randint(a,size=ea)
V = np.ones(ea)
A = sparse.coo_matrix((V,(I,J)),shape=(a,a))
U0,S,Vt = linalg.svds(A,k=3)

I = np.random.randint(a,size=ea)
J = np.random.randint(a,size=ea)
shift = a
for i in range(x):
	b = bs[i]
	eb = ebs[i]
	I = np.append(I,shift+np.random.randint(b,size=eb))
	J = np.append(J,shift+np.random.randint(b,size=eb))
	shift += b
V = np.ones(e)
A = sparse.coo_matrix((V,(I,J)),shape=(n,n))
U,S,Vt = linalg.svds(A,k=3)

plt.figure(4)
plt.subplot(221)
pdscatter = plt.scatter(U0[:,0],U0[:,1])
plt.subplot(222)
pdscatter = plt.scatter(U[:,0],U[:,1])
plt.subplot(223)
pdscatter = plt.scatter(U[:,0],U[:,2])
plt.subplot(224)
pdscatter = plt.scatter(U[:,1],U[:,2])
plt.show()


# In[6]:


x = 3
a = 1000
bs = [50,100,200]
n = a+sum(bs)
ea = 10*a
d = 0.1
ebs = [int(d*b*b) for b in bs]
e = ea+sum(ebs)
print n,ebs,e


# In[7]:


I = np.random.randint(a,size=ea)
J = np.random.randint(a,size=ea)
V = np.ones(ea)
A = sparse.coo_matrix((V,(I,J)),shape=(a,a))
U0,S,Vt = linalg.svds(A,k=3)

I = np.random.randint(a,size=ea)
J = np.random.randint(a,size=ea)
shift = a
for i in range(x):
	b = bs[i]
	eb = ebs[i]
	I = np.append(I,shift+np.random.randint(b,size=eb))
	J = np.append(J,shift+np.random.randint(b,size=eb))
	shift += b
V = np.ones(e)
A = sparse.coo_matrix((V,(I,J)),shape=(n,n))
U,S,Vt = linalg.svds(A,k=3)

plt.figure(4)
plt.subplot(221)
pdscatter = plt.scatter(U0[:,0],U0[:,1])
plt.subplot(222)
pdscatter = plt.scatter(U[:,0],U[:,1])
plt.subplot(223)
pdscatter = plt.scatter(U[:,0],U[:,2])
plt.subplot(224)
pdscatter = plt.scatter(U[:,1],U[:,2])
plt.show()


# In[8]:


x = 3
a = 1000
bs = [50,100,200]
n = a+sum(bs)
ea = 10*a
d = 0.01
ebs = [int(d*b*b) for b in bs]
e = ea+sum(ebs)
print n,ebs,e

I = np.random.randint(a,size=ea)
J = np.random.randint(a,size=ea)
V = np.ones(ea)
A = sparse.coo_matrix((V,(I,J)),shape=(a,a))
U0,S,Vt = linalg.svds(A,k=3)

I = np.random.randint(a,size=ea)
J = np.random.randint(a,size=ea)
shift = a
for i in range(x):
	b = bs[i]
	eb = ebs[i]
	I = np.append(I,shift+np.random.randint(b,size=eb))
	J = np.append(J,shift+np.random.randint(b,size=eb))
	shift += b
V = np.ones(e)
A = sparse.coo_matrix((V,(I,J)),shape=(n,n))
U,S,Vt = linalg.svds(A,k=3)

plt.figure(4)
plt.subplot(221)
pdscatter = plt.scatter(U0[:,0],U0[:,1])
plt.subplot(222)
pdscatter = plt.scatter(U[:,0],U[:,1])
plt.subplot(223)
pdscatter = plt.scatter(U[:,0],U[:,2])
plt.subplot(224)
pdscatter = plt.scatter(U[:,1],U[:,2])
plt.show()

